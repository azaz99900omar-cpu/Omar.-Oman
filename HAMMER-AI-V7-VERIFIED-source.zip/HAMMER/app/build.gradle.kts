plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    namespace="om.hammer.ai"
    compileSdk=35
    defaultConfig { applicationId="om.hammer.ai"; minSdk=30; targetSdk=35; versionCode=70; versionName="7.0" }
    buildFeatures { buildConfig=true }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
}
