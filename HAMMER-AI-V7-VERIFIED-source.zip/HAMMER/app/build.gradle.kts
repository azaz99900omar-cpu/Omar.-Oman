plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace="om.hammer.ai"
    compileSdk=35
    defaultConfig { applicationId="om.hammer.ai"; minSdk=30; targetSdk=35; versionCode=70; versionName="7.0" }
    buildFeatures { buildConfig=true }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
}
