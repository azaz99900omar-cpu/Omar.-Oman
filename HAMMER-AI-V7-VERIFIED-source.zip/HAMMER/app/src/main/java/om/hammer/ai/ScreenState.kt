package om.hammer.ai
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
class ScreenState {
 fun tree(root:AccessibilityNodeInfo?):String{
  val a=JSONArray()
  fun walk(n:AccessibilityNodeInfo?,depth:Int){
   if(n==null||depth>12||a.length()>300)return
   val r=android.graphics.Rect();n.getBoundsInScreen(r)
   a.put(JSONObject().put("text",n.text?.toString()?:"").put("desc",n.contentDescription?.toString()?:"")
    .put("class",n.className?.toString()?:"").put("clickable",n.isClickable).put("scrollable",n.isScrollable)
    .put("bounds","${r.left},${r.top},${r.right},${r.bottom}"))
   for(i in 0 until n.childCount) walk(n.getChild(i),depth+1)
  };walk(root,0);return a.toString()
 }
}
