package om.hammer.ai
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
class GameMemory(ctx:Context){
 private val p=ctx.getSharedPreferences("hammer_game_memory",Context.MODE_PRIVATE)
 fun observe(pkg:String,success:Boolean,confidence:Double,summary:String,actions:List<AiAction>){
  val o=JSONObject(p.getString(pkg,"{}")?:"{}")
  val attempts=o.optInt("attempts")+1; val wins=o.optInt("successes")+(if(success)1 else 0)
  val mastery=((wins.toDouble()/attempts)*75.0+confidence.coerceIn(0.0,1.0)*25.0).toInt().coerceIn(0,100)
  val hist=o.optJSONArray("history")?:JSONArray()
  hist.put(JSONObject().put("success",success).put("summary",summary.take(300)).put("actions",actions.joinToString(","){it.type}))
  while(hist.length()>30) hist.remove(0)
  o.put("attempts",attempts).put("successes",wins).put("mastery",mastery).put("history",hist)
  p.edit().putString(pkg,o.toString()).apply()
 }
 fun mastery(pkg:String)=JSONObject(p.getString(pkg,"{}")?:"{}").optInt("mastery")
 fun summary(pkg:String):String{
  val o=JSONObject(p.getString(pkg,"{}")?:"{}")
  return JSONObject().put("attempts",o.optInt("attempts")).put("successes",o.optInt("successes"))
   .put("mastery",o.optInt("mastery")).put("recent",o.optJSONArray("history")?:JSONArray()).toString()
 }
}
