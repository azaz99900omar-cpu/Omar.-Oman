package om.hammer.ai
import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.*
import android.widget.*
class OverlayController(private val s:HammerAccessibilityService){
 private val wm=s.getSystemService(AccessibilityService.WINDOW_SERVICE) as WindowManager;private var panel:LinearLayout?=null
 private fun glass(circle:Boolean=false)=GradientDrawable().apply{shape=if(circle)GradientDrawable.OVAL else GradientDrawable.RECTANGLE;cornerRadius=42f;setColor(0x22FFFFFF);setStroke(2,0x88FFFFFF.toInt())}
 fun show(){
  val orb=TextView(s).apply{text="AI";textSize=21f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=glass(true);elevation=12f}
  val lp=WindowManager.LayoutParams(142,142,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.END or Gravity.CENTER_VERTICAL;x=24}
  var sx=0f;var sy=0f;var ox=0;var oy=0
  orb.setOnTouchListener{_,e->when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=lp.x;oy=lp.y;orb.animate().scaleX(.82f).scaleY(.82f).alpha(.72f).setDuration(100).start();true};MotionEvent.ACTION_MOVE->{lp.x=ox-(e.rawX-sx).toInt();lp.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(orb,lp);true};MotionEvent.ACTION_UP->{orb.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(260).start();if(kotlin.math.abs(e.rawX-sx)<20&&kotlin.math.abs(e.rawY-sy)<20)toggle(lp);true};else->false}}
  wm.addView(orb,lp)
 }
 private fun toggle(a:WindowManager.LayoutParams){
  panel?.let{it.animate().alpha(0f).scaleX(.15f).scaleY(.15f).translationX(180f).setDuration(220).withEndAction{try{wm.removeView(it)}catch(_:Throwable){}}.start();panel=null;return}
  val box=LinearLayout(s).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24);background=glass();layoutDirection=View.LAYOUT_DIRECTION_RTL;elevation=16f}
  fun button(t:String,fn:()->Unit)=Button(s).apply{text=t;setOnClickListener{fn()}}
  box.addView(TextView(s).apply{text="مساعد AI";textSize=20f;setTextColor(Color.WHITE);gravity=Gravity.CENTER})
  box.addView(button("تعلّم"){s.startLearn();Toast.makeText(s,"بدأ وضع التعلّم",Toast.LENGTH_SHORT).show()})
  box.addView(button("تشغيل تلقائي"){s.startPlay();Toast.makeText(s,"بدأ التشغيل التلقائي",Toast.LENGTH_SHORT).show()})
  box.addView(button("إيقاف"){s.stopAgent();Toast.makeText(s,"تم الإيقاف",Toast.LENGTH_SHORT).show()})
  val p=WindowManager.LayoutParams(420,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.END or Gravity.CENTER_VERTICAL;x=180;y=a.y}
  box.alpha=0f;box.scaleX=.12f;box.scaleY=.12f;box.translationX=170f;wm.addView(box,p);box.animate().alpha(1f).scaleX(1f).scaleY(1f).translationX(0f).setDuration(300).start();panel=box
 }
}
