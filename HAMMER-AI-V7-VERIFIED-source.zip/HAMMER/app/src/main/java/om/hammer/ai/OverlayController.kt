package om.hammer.ai
import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
class OverlayController(private val s:HammerAccessibilityService){
 private val wm=s.getSystemService(AccessibilityService.WINDOW_SERVICE) as WindowManager; private var panel:LinearLayout?=null
 fun show(){
  val orb=TextView(s).apply{text="AI";textSize=20f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=glass(true)}
  val lp=WindowManager.LayoutParams(150,150,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.END or Gravity.CENTER_VERTICAL;x=24}
  var sx=0f;var sy=0f;var ox=0;var oy=0
  orb.setOnTouchListener{_,e->when(e.action){
   MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=lp.x;oy=lp.y;orb.animate().scaleX(.84f).scaleY(.84f).alpha(.58f).setDuration(110).start();true}
   MotionEvent.ACTION_MOVE->{lp.x=ox-(e.rawX-sx).toInt();lp.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(orb,lp);true}
   MotionEvent.ACTION_UP->{orb.animate().scaleX(1f).scaleY(1f).alpha(.94f).setDuration(430).start();if(kotlin.math.abs(e.rawX-sx)<20&&kotlin.math.abs(e.rawY-sy)<20)toggle(lp);true}
   else->false}}
  wm.addView(orb,lp)
  fun pulse(){orb.animate().alpha(.64f).setDuration(2100).withEndAction{orb.animate().alpha(.96f).setDuration(2100).withEndAction{pulse()}.start()}.start()};pulse()
 }
 private fun glass(circle:Boolean)=GradientDrawable().apply{shape=if(circle)GradientDrawable.OVAL else GradientDrawable.RECTANGLE;cornerRadius=46f;setColor(0xA825303D.toInt());setStroke(2,0x66FFFFFF)}
 private fun toggle(a:WindowManager.LayoutParams){
  panel?.let{it.animate().alpha(0f).scaleX(.72f).scaleY(.72f).setDuration(180).withEndAction{wm.removeView(it)}.start();panel=null;return}
  val box=LinearLayout(s).apply{orientation=LinearLayout.VERTICAL;setPadding(28,26,28,26);background=glass(false)}
  fun b(t:String,fn:()->Unit)=Button(s).apply{text=t;setOnClickListener{fn()}}
  box.addView(TextView(s).apply{text="HAMMER AI";textSize=20f;setTextColor(Color.WHITE)})
  box.addView(b("LEARN"){s.startLearn();Toast.makeText(s,"HAMMER learning",Toast.LENGTH_SHORT).show()})
  box.addView(b("AUTO PLAY"){s.startPlay();Toast.makeText(s,"HAMMER playing",Toast.LENGTH_SHORT).show()})
  box.addView(b("STOP"){s.stopAgent()})
  val lp=WindowManager.LayoutParams(430,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.END or Gravity.CENTER_VERTICAL;x=185;y=a.y}
  box.alpha=0f;box.scaleX=.68f;box.scaleY=.68f;wm.addView(box,lp);box.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(340).start();panel=box
 }
}
