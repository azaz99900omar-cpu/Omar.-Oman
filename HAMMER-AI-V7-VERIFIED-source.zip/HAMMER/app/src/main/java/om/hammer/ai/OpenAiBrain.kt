package om.hammer.ai
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class OpenAiBrain(private val cfg:BrainConfig){
 private val io=Executors.newSingleThreadExecutor()
 fun testConnection(done:(Result<String>)->Unit){
  if(!cfg.ready()){done(Result.failure(IllegalStateException("مفتاح OpenAI غير صالح")));return}
  io.execute{
   try{
    val body=JSONObject().put("model",cfg.model).put("input","أجب بكلمة OK فقط").put("max_output_tokens",16)
    val raw=post(body)
    val root=JSONObject(raw)
    val text=extractText(root).ifBlank{"OK"}
    done(Result.success(text))
   }catch(t:Throwable){done(Result.failure(t))}
  }
 }
 fun decide(pkg:String,nodes:String,jpeg:ByteArray?,memory:String,mode:String,done:(Result<AiPlan>)->Unit){
  if(!cfg.ready()){done(Result.failure(IllegalStateException("مفتاح OpenAI غير مضبوط")));return}
  io.execute{
   try{
    val instruction="""أنت عقل HAMMER، مساعد ألعاب يعمل على جهاز المستخدم فقط.
حلل لقطة الشاشة وشجرة إمكانية الوصول والذاكرة السابقة، وتعلم من النتائج السابقة.
أرجع JSON فقط بهذا الشكل: {"summary":"...","confidence":0.0,"actions":[...]}.
أنواع الأفعال المسموحة: tap,double_tap,long_press,swipe,drag,wait. الإحداثيات هي بكسلات مطلقة للشاشة.
لا تتفاعل مع الشراء أو الدفع أو الاشتراكات أو كلمات المرور أو إعدادات الحساب والأمان أو نوافذ الأذونات أو واجهة نظام Android.
إذا لم تكن متأكداً استخدم wait. الحد الأقصى 12 فعلاً. في وضع التعلم فضّل الملاحظة والتجارب الآمنة، وفي التشغيل التلقائي أعد استخدام الاستراتيجيات الناجحة."""
    val content=JSONArray().put(JSONObject().put("type","input_text").put("text","الوضع=$mode\nالحزمة=$pkg\nالذاكرة=$memory\nشجرة الشاشة=$nodes"))
    if(jpeg!=null) content.put(JSONObject().put("type","input_image").put("image_url","data:image/jpeg;base64,"+Base64.encodeToString(jpeg,Base64.NO_WRAP)))
    val body=JSONObject().put("model",cfg.model).put("instructions",instruction)
      .put("input",JSONArray().put(JSONObject().put("role","user").put("content",content))).put("max_output_tokens",1200)
    val text=extractText(JSONObject(post(body))).trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
    done(Result.success(parsePlan(text)))
   }catch(t:Throwable){done(Result.failure(t))}
  }
 }
 private fun post(body:JSONObject):String{
  val c=(URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply{
   requestMethod="POST";connectTimeout=15000;readTimeout=60000;doOutput=true
   setRequestProperty("Authorization","Bearer ${cfg.apiKey}");setRequestProperty("Content-Type","application/json")
  }
  c.outputStream.use{it.write(body.toString().toByteArray())}
  val stream=if(c.responseCode in 200..299)c.inputStream else c.errorStream
  val raw=stream?.bufferedReader()?.use{it.readText()} ?: ""
  if(c.responseCode !in 200..299){
   val msg=try{JSONObject(raw).optJSONObject("error")?.optString("message")?:raw}catch(_:Throwable){raw}
   throw IllegalStateException("OpenAI ${c.responseCode}: ${msg.take(220)}")
  }
  return raw
 }
 private fun extractText(root:JSONObject):String{
  val output=root.optJSONArray("output")?:JSONArray();var text=""
  for(i in 0 until output.length()){
   val item=output.optJSONObject(i)?:continue;val ca=item.optJSONArray("content")?:continue
   for(j in 0 until ca.length()){val q=ca.optJSONObject(j)?:continue;if(q.optString("type")=="output_text")text+=q.optString("text")}
  }
  return text
 }
 private fun parsePlan(json:String):AiPlan{
  val o=JSONObject(json);val arr=o.optJSONArray("actions")?:JSONArray();val out=mutableListOf<AiAction>()
  for(i in 0 until minOf(arr.length(),12)){val a=arr.optJSONObject(i)?:continue;val t=a.optString("type")
   if(t in setOf("tap","double_tap","long_press","swipe","drag","wait"))out+=AiAction(t,a.optDouble("x1").toFloat(),a.optDouble("y1").toFloat(),a.optDouble("x2").toFloat(),a.optDouble("y2").toFloat(),a.optLong("durationMs"))
  }
  return AiPlan(o.optString("summary"),o.optDouble("confidence",0.0).coerceIn(0.0,1.0),out)
 }
}
