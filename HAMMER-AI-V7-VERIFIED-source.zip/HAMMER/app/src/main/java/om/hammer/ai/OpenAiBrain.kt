package om.hammer.ai
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class OpenAiBrain(private val cfg:BrainConfig){
 private val io=Executors.newSingleThreadExecutor()
 fun decide(pkg:String,nodes:String,jpeg:ByteArray?,memory:String,mode:String,done:(Result<AiPlan>)->Unit){
  if(!cfg.ready()){done(Result.failure(IllegalStateException("OpenAI API key not configured")));return}
  io.execute{
   try{
    val instruction="""You are the decision brain for HAMMER, an Android game assistant operating only on the user's own device.
Study the screenshot, accessibility tree and prior memory. Learn from prior outcomes.
Return ONLY a JSON object: {"summary":"...","confidence":0.0,"actions":[...]}.
Allowed action types: tap,double_tap,long_press,swipe,drag,wait. Coordinates are absolute screen pixels.
Never interact with purchases, payments, subscriptions, passwords, account/security dialogs, permission dialogs, ads that lead to purchases, or Android system UI.
If uncertain, return wait. Use at most 12 actions. In learn mode favor observation and safe experiments; in play mode reuse successful strategies."""
    val content=JSONArray().put(JSONObject().put("type","input_text").put("text",
      "Mode=$mode\nPackage=$pkg\nMemory=$memory\nAccessibilityTree=$nodes"))
    if(jpeg!=null) content.put(JSONObject().put("type","input_image")
      .put("image_url","data:image/jpeg;base64,"+Base64.encodeToString(jpeg,Base64.NO_WRAP)))
    val body=JSONObject().put("model",cfg.model).put("instructions",instruction)
      .put("input",JSONArray().put(JSONObject().put("role","user").put("content",content)))
      .put("max_output_tokens",1200)
    val c=(URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply{
      requestMethod="POST";connectTimeout=15000;readTimeout=60000;doOutput=true
      setRequestProperty("Authorization","Bearer ${cfg.apiKey}")
      setRequestProperty("Content-Type","application/json")
    }
    c.outputStream.use{it.write(body.toString().toByteArray())}
    val stream=if(c.responseCode in 200..299)c.inputStream else c.errorStream
    val raw=stream.bufferedReader().use{it.readText()}
    if(c.responseCode !in 200..299) throw IllegalStateException("OpenAI HTTP ${c.responseCode}: ${raw.take(250)}")
    val root=JSONObject(raw); val output=root.optJSONArray("output")?:JSONArray()
    var text=""
    for(i in 0 until output.length()){
      val item=output.optJSONObject(i)?:continue
      val ca=item.optJSONArray("content")?:continue
      for(j in 0 until ca.length()){ val q=ca.optJSONObject(j)?:continue
        if(q.optString("type")=="output_text") text+=q.optString("text")
      }
    }
    text=text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
    done(Result.success(parsePlan(text)))
   }catch(t:Throwable){done(Result.failure(t))}
  }
 }
 private fun parsePlan(json:String):AiPlan{
  val o=JSONObject(json);val arr=o.optJSONArray("actions")?:JSONArray();val out=mutableListOf<AiAction>()
  for(i in 0 until minOf(arr.length(),12)){val a=arr.optJSONObject(i)?:continue;val t=a.optString("type")
   if(t in setOf("tap","double_tap","long_press","swipe","drag","wait"))
    out+=AiAction(t,a.optDouble("x1").toFloat(),a.optDouble("y1").toFloat(),a.optDouble("x2").toFloat(),a.optDouble("y2").toFloat(),a.optLong("durationMs"))
  }
  return AiPlan(o.optString("summary"),o.optDouble("confidence",0.0).coerceIn(0.0,1.0),out)
 }
}
