package om.hammer.ai
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.text.InputType
import android.widget.*

class MainActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val cfg=BrainConfig(this)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(54,40,54,40);setBackgroundColor(Color.rgb(8,11,18))}
  val orb=TextView(this).apply{text="AI";textSize=36f;gravity=Gravity.CENTER;setTextColor(Color.WHITE)
   background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0x30FFFFFF);setStroke(2,0x70FFFFFF)};layoutParams=LinearLayout.LayoutParams(220,220)}
  root.addView(orb);root.addView(TextView(this).apply{text="\nHAMMER AI";textSize=30f;setTextColor(Color.WHITE);gravity=Gravity.CENTER})
  val key=EditText(this).apply{hint="OpenAI API key";setText(cfg.apiKey);setTextColor(Color.WHITE);setHintTextColor(0x77FFFFFF)
   inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
  val model=EditText(this).apply{hint="Model";setText(cfg.model);setTextColor(Color.WHITE);setHintTextColor(0x77FFFFFF)}
  root.addView(key);root.addView(model)
  root.addView(Button(this).apply{text="SAVE OPENAI CONNECTION";setOnClickListener{
    cfg.apiKey=key.text.toString();cfg.model=model.text.toString().ifBlank{"gpt-5.6-sol"}
    Toast.makeText(this@MainActivity,if(cfg.ready())"OpenAI connected settings saved" else "Enter a valid API key",Toast.LENGTH_SHORT).show()
  }})
  root.addView(Button(this).apply{text="ENABLE HAMMER";setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}})
  root.addView(TextView(this).apply{text="\nDirect: Game → HAMMER → OpenAI → HAMMER → Game\nScreenshots stay in memory and are not saved to Gallery.";setTextColor(0x99FFFFFF.toInt());gravity=Gravity.CENTER})
  setContentView(root)
 }
}
