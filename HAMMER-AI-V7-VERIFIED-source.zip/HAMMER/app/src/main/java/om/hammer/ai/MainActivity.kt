package om.hammer.ai
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.text.InputType
import android.widget.*

class MainActivity:Activity(){
 private fun glass(radius:Float=34f)=GradientDrawable().apply{cornerRadius=radius;setColor(0x142FFFFFF);setStroke(2,0x55FFFFFF)}
 override fun onCreate(b:Bundle?){super.onCreate(b);window.statusBarColor=Color.TRANSPARENT;window.navigationBarColor=Color.TRANSPARENT;val cfg=BrainConfig(this)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(58,34,58,34);setBackgroundColor(Color.rgb(18,25,35));layoutDirection=android.view.View.LAYOUT_DIRECTION_RTL}
  val orb=TextView(this).apply{text="AI";textSize=34f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0x22FFFFFF);setStroke(2,0x88FFFFFF)};layoutParams=LinearLayout.LayoutParams(180,180)}
  root.addView(orb);root.addView(TextView(this).apply{text="\nمساعد الألعاب الذكي";textSize=27f;setTextColor(Color.WHITE);gravity=Gravity.CENTER})
  root.addView(TextView(this).apply{text="يتعلم من شاشتك وينفذ الأوامر على جهازك";textSize=15f;setTextColor(0xAAFFFFFF.toInt());gravity=Gravity.CENTER})
  val key=EditText(this).apply{hint="مفتاح OpenAI";setText(cfg.apiKey);setTextColor(Color.WHITE);setHintTextColor(0x88FFFFFF.toInt());inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;background=glass();setPadding(28,12,28,12)}
  val model=EditText(this).apply{hint="الموديل";setText(cfg.model);setTextColor(Color.WHITE);setHintTextColor(0x88FFFFFF.toInt());background=glass();setPadding(28,12,28,12)}
  val status=TextView(this).apply{text="غير متصل";textSize=16f;setTextColor(0xCCFFFFFF.toInt());gravity=Gravity.CENTER;setPadding(10,16,10,16)}
  root.addView(key,LinearLayout.LayoutParams(-1,70).apply{setMargins(0,22,0,12)});root.addView(model,LinearLayout.LayoutParams(-1,70).apply{setMargins(0,0,0,12)})
  val save=Button(this).apply{text="حفظ واختبار اتصال OpenAI";setOnClickListener{
   cfg.apiKey=key.text.toString();cfg.model=model.text.toString().ifBlank{"gpt-5.6-sol"}
   if(!cfg.ready()){status.text="❌ المفتاح غير صالح";return@setOnClickListener}
   status.text="⏳ جارٍ اختبار الاتصال...";isEnabled=false
   OpenAiBrain(cfg).testConnection{r->runOnUiThread{isEnabled=true;r.onSuccess{status.text="✓ تم الاتصال بنجاح"}.onFailure{status.text="❌ فشل الاتصال: ${it.message?.take(120)?:"خطأ غير معروف"}"}}}
  }}
  root.addView(save,LinearLayout.LayoutParams(-1,72));root.addView(status,LinearLayout.LayoutParams(-1,-2))
  root.addView(Button(this).apply{text="تفعيل مساعد AI";setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}},LinearLayout.LayoutParams(-1,72))
  root.addView(TextView(this).apply{text="\nاللعبة ← HAMMER ← OpenAI ← HAMMER ← اللعبة\nلقطات الشاشة تبقى في الذاكرة ولا تُحفظ في المعرض.";setTextColor(0xAAFFFFFF.toInt());gravity=Gravity.CENTER;textSize=14f})
  setContentView(root)
 }
}
