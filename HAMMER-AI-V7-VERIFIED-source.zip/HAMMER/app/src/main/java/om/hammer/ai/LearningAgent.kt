package om.hammer.ai
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.security.MessageDigest

class LearningAgent(private val s:HammerAccessibilityService){
 private val h=Handler(Looper.getMainLooper())
 private val cfg=BrainConfig(s); private val brain=OpenAiBrain(cfg)
 private var running=false; private var mode="learn"; private var lastHash=""; private var repeated=0
 fun start(m:String){mode=m;running=true;cycle()}
 fun stop(){running=false;h.removeCallbacksAndMessages(null)}
 private fun hash(b:ByteArray?)=b?.let{MessageDigest.getInstance("SHA-256").digest(it).take(8).joinToString(""){"%02x".format(it)}}?:""
 private fun cycle(){
  if(!running)return
  s.snapshot{jpg,pkg,nodes->
   if(pkg.startsWith("om.hammer.ai")){h.postDelayed({cycle()},800);return@snapshot}
   val now=hash(jpg); repeated=if(now==lastHash) repeated+1 else 0; lastHash=now
   val mem=s.memory.summary(pkg)
   brain.decide(pkg,nodes,jpg,mem,mode){r->
    h.post{
     if(!running)return@post
     r.onSuccess{plan->
      val safe=plan.actions.filter{a-> valid(a,s.displayMetrics.widthPixels,s.displayMetrics.heightPixels)}
      s.gestures.sequence(safe){
       h.postDelayed({
        s.snapshot{after,_,_->
         val changed=hash(after)!=now
         s.memory.observe(pkg,changed,plan.confidence,plan.summary,safe)
         h.postDelayed({cycle()}, if(mode=="learn")900 else 350)
        }
       },500)
      }
     }.onFailure{h.postDelayed({cycle()},2500)}
    }
   }
  }
 }
 private fun valid(a:AiAction,w:Int,h:Int):Boolean{
  fun p(x:Float,y:Float)=x>=0&&y>=0&&x<=w&&y<=h
  return when(a.type){"tap","double_tap","long_press"->p(a.x1,a.y1);"swipe","drag"->p(a.x1,a.y1)&&p(a.x2,a.y2);"wait"->true;else->false}
 }
}
