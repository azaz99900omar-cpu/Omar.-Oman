package om.hammer.ai
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper

class GestureEngine(private val service:AccessibilityService){
 private val h=Handler(Looper.getMainLooper())
 private fun stroke(path:Path,start:Long,duration:Long)=GestureDescription.StrokeDescription(path,start,duration)
 private fun dispatch(vararg s:GestureDescription.StrokeDescription):Boolean{
  val b=GestureDescription.Builder(); s.forEach{b.addStroke(it)}; return service.dispatchGesture(b.build(),null,null)
 }
 fun tap(x:Float,y:Float)=dispatch(stroke(Path().apply{moveTo(x,y)},0,55))
 fun doubleTap(x:Float,y:Float)=dispatch(stroke(Path().apply{moveTo(x,y)},0,50),stroke(Path().apply{moveTo(x,y)},110,50))
 fun longPress(x:Float,y:Float,ms:Long=650)=dispatch(stroke(Path().apply{moveTo(x,y)},0,ms))
 fun swipe(x1:Float,y1:Float,x2:Float,y2:Float,ms:Long=320)=dispatch(stroke(Path().apply{moveTo(x1,y1);lineTo(x2,y2)},0,ms))
 fun drag(x1:Float,y1:Float,x2:Float,y2:Float,ms:Long=850)=swipe(x1,y1,x2,y2,ms)
 fun simultaneousTaps(points:List<Pair<Float,Float>>):Boolean{
  if(points.isEmpty()) return false
  return dispatch(*points.map{stroke(Path().apply{moveTo(it.first,it.second)},0,70)}.toTypedArray())
 }
 fun sequence(actions:List<AiAction>,done:()->Unit={}){
  fun next(i:Int){ if(i>=actions.size){done();return}; val a=actions[i]
   when(a.type.lowercase()){
    "wait"->{}
    "tap"->tap(a.x1,a.y1); "double_tap"->doubleTap(a.x1,a.y1); "long_press"->longPress(a.x1,a.y1,a.durationMs.coerceAtLeast(500))
    "swipe"->swipe(a.x1,a.y1,a.x2,a.y2,a.durationMs.coerceAtLeast(180)); "drag"->drag(a.x1,a.y1,a.x2,a.y2,a.durationMs.coerceAtLeast(400))
   }
   h.postDelayed({next(i+1)},(a.durationMs.coerceAtLeast(80)+100))
  }; next(0)
 }
}
