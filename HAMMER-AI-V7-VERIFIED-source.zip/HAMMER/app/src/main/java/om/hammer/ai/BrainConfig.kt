package om.hammer.ai

import android.content.Context

class BrainConfig(context: Context) {
    private val prefs = context.getSharedPreferences("hammer_brain", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("openai_key", "") ?: ""
        set(value) {
            prefs.edit().putString("openai_key", value.trim()).apply()
        }

    var model: String
        get() = prefs.getString("model", "gpt-5.6-sol") ?: "gpt-5.6-sol"
        set(value) {
            prefs.edit().putString("model", value.trim()).apply()
        }

    fun ready(): Boolean = apiKey.startsWith("sk-") && apiKey.length > 20
}
