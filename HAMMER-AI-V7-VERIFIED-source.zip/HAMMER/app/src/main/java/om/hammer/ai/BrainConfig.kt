package om.hammer.ai

import android.content.Context

class BrainConfig(context: Context) {
    private val prefs = context.getSharedPreferences("hammer_brain", Context.MODE_PRIVATE)

    private fun cleanSecret(value: String): String = value
        .replace("\\u200B", "")
        .replace("\\u200C", "")
        .replace("\\u200D", "")
        .replace("\\uFEFF", "")
        .replace(Regex("\\s+"), "")
        .trim()

    var apiKey: String
        get() = cleanSecret(prefs.getString("openai_key", "") ?: "")
        set(value) { prefs.edit().putString("openai_key", cleanSecret(value)).apply() }

    var model: String
        get() = (prefs.getString("model", "gpt-5.2") ?: "gpt-5.2").trim()
        set(value) { prefs.edit().putString("model", value.trim()).apply() }

    fun ready(): Boolean = apiKey.startsWith("sk-") && apiKey.length > 20
}
