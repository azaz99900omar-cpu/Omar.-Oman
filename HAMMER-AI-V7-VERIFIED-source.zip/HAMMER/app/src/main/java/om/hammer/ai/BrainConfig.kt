package om.hammer.ai
import android.content.Context
class BrainConfig(ctx:Context){
 private val p=ctx.getSharedPreferences("hammer_brain",Context.MODE_PRIVATE)
 var apiKey:String get()=p.getString("openai_key","")?:"" set(v){p.edit().putString("openai_key",v.trim()).apply()}
 var model:String get()=p.getString("model","gpt-5.6-sol")?:"gpt-5.6-sol" set(v){p.edit().putString("model",v.trim()).apply()}
 fun ready()=apiKey.startsWith("sk-") && apiKey.length>20
}
