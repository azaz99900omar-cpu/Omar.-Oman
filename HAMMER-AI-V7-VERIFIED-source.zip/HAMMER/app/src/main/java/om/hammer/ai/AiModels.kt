package om.hammer.ai
data class AiAction(val type:String,val x1:Float=0f,val y1:Float=0f,val x2:Float=0f,val y2:Float=0f,val durationMs:Long=0)
data class AiPlan(val summary:String,val confidence:Double,val actions:List<AiAction>)
