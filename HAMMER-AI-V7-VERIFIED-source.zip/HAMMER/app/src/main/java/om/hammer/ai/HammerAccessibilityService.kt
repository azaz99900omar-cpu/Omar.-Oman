package om.hammer.ai
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.graphics.Bitmap
import android.util.DisplayMetrics
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import java.io.ByteArrayOutputStream

class HammerAccessibilityService:AccessibilityService(){
 lateinit var gestures:GestureEngine; lateinit var memory:GameMemory; lateinit var agent:LearningAgent
 val displayMetrics:DisplayMetrics get()=resources.displayMetrics
 override fun onServiceConnected(){gestures=GestureEngine(this);memory=GameMemory(this);agent=LearningAgent(this);OverlayController(this).show()}
 override fun onAccessibilityEvent(event:AccessibilityEvent?){}
 override fun onInterrupt(){if(::agent.isInitialized)agent.stop()}
 fun startLearn(){agent.start("learn")}
 fun startPlay(){agent.start("play")}
 fun stopAgent(){agent.stop()}
 fun snapshot(done:(ByteArray?,String,String)->Unit){
  val pkg=rootInActiveWindow?.packageName?.toString()?:"unknown"; val nodes=ScreenState().tree(rootInActiveWindow)
  takeScreenshot(Display.DEFAULT_DISPLAY,mainExecutor,object:TakeScreenshotCallback{
   override fun onSuccess(r:ScreenshotResult){val hb=r.hardwareBuffer;val b=Bitmap.wrapHardwareBuffer(hb,r.colorSpace)
    if(b==null){hb.close();done(null,pkg,nodes);return};val out=ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.JPEG,76,out);hb.close();done(out.toByteArray(),pkg,nodes)}
   override fun onFailure(code:Int){done(null,pkg,nodes)}
  })
 }
}
