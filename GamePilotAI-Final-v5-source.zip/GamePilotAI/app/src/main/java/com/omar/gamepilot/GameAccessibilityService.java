package com.omar.gamepilot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.pm.ApplicationInfo;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.util.Base64;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.Executor;

public class GameAccessibilityService extends AccessibilityService {
    private WindowManager wm; private TextView bubble; private LinearLayout panel; private WindowManager.LayoutParams bubbleLp;
    private final Handler h=new Handler(Looper.getMainLooper()); private String pkg=""; private boolean discovering=false,playing=false; private int step=0; private float dx,dy; private int sx,sy; private AnimatorSet pulse;
    private final Random rng=new Random(7);
    @Override protected void onServiceConnected(){wm=(WindowManager)getSystemService(WINDOW_SERVICE); createBubble(); toast("GamePilot AI V5 جاهز");}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){if(e.getPackageName()==null)return;String p=e.getPackageName().toString();if(p.equals(getPackageName())||p.startsWith("com.android.systemui")||p.contains("permissioncontroller"))return;pkg=p;}
    @Override public void onInterrupt(){stop();}
    @Override public void onDestroy(){stop();rm(panel);rm(bubble);super.onDestroy();}

    private void createBubble(){
        bubble=new TextView(this); bubble.setText("✦\nAI");bubble.setTextColor(Color.WHITE);bubble.setTextSize(13);bubble.setGravity(Gravity.CENTER);bubble.setTypeface(null,1);bubble.setElevation(dp(18));
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(98,72,255),Color.rgb(0,190,255)});g.setShape(GradientDrawable.OVAL);g.setStroke(dp(2),Color.argb(180,255,255,255));bubble.setBackground(g);
        bubbleLp=new WindowManager.LayoutParams(dp(66),dp(66),WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);bubbleLp.gravity=Gravity.END|Gravity.CENTER_VERTICAL;bubbleLp.x=dp(10);wm.addView(bubble,bubbleLp);
        bubble.setOnTouchListener((v,e)->{if(e.getAction()==0){dx=e.getRawX();dy=e.getRawY();sx=bubbleLp.x;sy=bubbleLp.y;return true;}if(e.getAction()==2){if(Math.abs(e.getRawX()-dx)+Math.abs(e.getRawY()-dy)>dp(8)){bubbleLp.x=Math.max(0,sx-Math.round(e.getRawX()-dx));bubbleLp.y=sy+Math.round(e.getRawY()-dy);try{wm.updateViewLayout(bubble,bubbleLp);}catch(Exception ignored){}}return true;}if(e.getAction()==1){if(Math.abs(e.getRawX()-dx)+Math.abs(e.getRawY()-dy)<dp(14))togglePanel();return true;}return true;});
        ObjectAnimator a=ObjectAnimator.ofFloat(bubble,View.ALPHA,.78f,1f,.78f),x=ObjectAnimator.ofFloat(bubble,View.SCALE_X,1f,1.12f,1f),y=ObjectAnimator.ofFloat(bubble,View.SCALE_Y,1f,1.12f,1f);for(ObjectAnimator q:new ObjectAnimator[]{a,x,y}){q.setDuration(1500);q.setRepeatCount(-1);}pulse=new AnimatorSet();pulse.playTogether(a,x,y);pulse.start();
    }
    private void togglePanel(){if(discovering||playing){stop();toast("تم الإيقاف");return;}if(panel!=null){rm(panel);panel=null;return;}panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(14),dp(14),dp(14),dp(14));GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(18,24,43),Color.rgb(30,35,68)});bg.setCornerRadius(dp(22));bg.setStroke(dp(1),Color.argb(90,120,210,255));panel.setBackground(bg);panel.setElevation(dp(18));
        TextView title=txt("✦ GamePilot AI FINAL",18,true);title.setGravity(Gravity.CENTER);panel.addView(title,lp(dp(250),dp(48)));
        TextView state=txt((discovering?"● يكتشف ويتعلّم":playing?"● يلعب عنك":"جاهز")+"\n"+gameName()+" • "+ProfileStore.learnedStates(this,pkg)+" حالة متعلّمة",12,false);state.setTextColor(Color.rgb(180,210,235));state.setGravity(Gravity.CENTER);panel.addView(state,lp(dp(250),dp(58)));
        Button learn=button("🧠  اكتشف وتعلّم");learn.setOnClickListener(v->startDiscover());panel.addView(learn,blp());
        Button play=button("▶  العب عني");play.setOnClickListener(v->startPlay());panel.addView(play,blp());
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(278),-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);p.gravity=Gravity.END|Gravity.CENTER_VERTICAL;p.x=dp(84);wm.addView(panel,p);
    }
    private void startDiscover(){stop();if(!valid()){toast("افتح اللعبة أولًا");return;}remember();discovering=true;rmPanel();toast("بدأ الاكتشاف الذاتي. سيجرّب ويتعلم بنفسه.");h.postDelayed(this::discoverLoop,600);}
    private void startPlay(){stop();if(!valid()){toast("افتح اللعبة أولًا");return;}remember();if(ProfileStore.learnedStates(this,pkg)==0){toast("اضغط «اكتشف وتعلّم» أولًا حتى يبني معرفة باللعبة.");return;}playing=true;rmPanel();toast("بدأ «العب عني». اضغط AI للإيقاف.");h.postDelayed(this::playLoop,500);}
    private void discoverLoop(){
        if(!discovering||!valid())return;
        capture(sig->{
            if(!discovering)return;
            final JSONObject brain=ProfileStore.loadBrain(this,pkg);
            final String key=stateKey(sig);
            JSONObject stateTmp=brain.optJSONObject(key);
            if(stateTmp==null)stateTmp=new JSONObject();
            final JSONObject state=stateTmp;
            JSONArray actionsTmp=state.optJSONArray("actions");
            if(actionsTmp==null)actionsTmp=new JSONArray();
            final JSONArray actions=actionsTmp;
            final Action action=chooseLearningAction(state,actions);
            final String before=sig;
            doAction(action,()->h.postDelayed(()->capture(after->{
                final int change=distance(before,after);
                final int reward=rewardHint()+Math.min(60,change)+(change>8?10:-8);
                updateActionKnowledge(actions,action,reward,change);
                try{
                    state.put("actions",actions);
                    state.put("visits",state.optInt("visits",0)+1);
                    state.put("lastReward",reward);
                    brain.put(key,state);
                    ProfileStore.saveBrain(this,pkg,brain);
                }catch(Exception ignored){}
                step++;
                h.postDelayed(this::discoverLoop,change<5?320:620);
            }),420));
        });
    }
    private void playLoop(){
        if(!playing||!valid())return;
        capture(sig->{
            JSONObject brain=ProfileStore.loadBrain(this,pkg);
            JSONObject state=brain.optJSONObject(stateKey(sig));
            Action action=bestAction(state);
            if(action==null)action=chooseAction(null,false);
            final Action selected=action;
            doAction(selected,()->h.postDelayed(this::playLoop,500));
        });
    }
    private Action chooseLearningAction(JSONObject state,JSONArray actions){
        List<Action> candidates=nodeActions();
        if(candidates.isEmpty())return chooseAction(actions,true);
        for(Action a:candidates)if(!seen(actions,a))return a;
        double best=-1e9; Action pick=candidates.get(0); int total=Math.max(1,state.optInt("visits",1));
        for(Action a:candidates){JSONObject rec=findAction(actions,a);double avg=rec==null?0:rec.optDouble("avg",rec.optInt("score",0));int n=rec==null?0:rec.optInt("tries",1);double ucb=avg+22.0*Math.sqrt(Math.log(total+2.0)/(n+1.0));if(ucb>best){best=ucb;pick=a;}}
        return pick;
    }
    private JSONObject findAction(JSONArray arr,Action a){for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o!=null&&Math.abs(o.optInt("x")-a.x)<dp(18)&&Math.abs(o.optInt("y")-a.y)<dp(18))return o;}return null;}
    private void updateActionKnowledge(JSONArray arr,Action a,int reward,int change){try{JSONObject rec=findAction(arr,a);if(rec==null){rec=a.json();rec.put("tries",0);rec.put("avg",0.0);arr.put(rec);}int n=rec.optInt("tries",0);double avg=rec.optDouble("avg",0.0);n++;avg+=((double)reward-avg)/n;rec.put("tries",n);rec.put("avg",avg);rec.put("score",(int)Math.round(avg));rec.put("change",change);}catch(Exception ignored){}}
    private Action chooseAction(JSONArray tried,boolean explore){List<Action> nodes=nodeActions();if(!nodes.isEmpty()){if(explore&&tried!=null){for(Action a:nodes)if(!seen(tried,a))return a;}return nodes.get(Math.abs(rng.nextInt())%nodes.size());}int w=getResources().getDisplayMetrics().widthPixels,hgt=getResources().getDisplayMetrics().heightPixels;float[] xs={.22f,.5f,.78f},ys={.28f,.48f,.68f,.82f};for(float y:ys)for(float x:xs){Action a=new Action(Math.round(w*x),Math.round(hgt*y),"grid");if(!explore||tried==null||!seen(tried,a))return a;}return new Action(w/2,(int)(hgt*.65f),"grid");}
    private List<Action> nodeActions(){List<Action> out=new ArrayList<>();AccessibilityNodeInfo r=getRootInActiveWindow();if(r!=null)walk(r,out);return out;}
    private void walk(AccessibilityNodeInfo n,List<Action> out){if(n==null||out.size()>24)return;CharSequence t=n.getText(),d=n.getContentDescription();String label=((t==null?"":t.toString())+" "+(d==null?"":d.toString())).toLowerCase(Locale.ROOT);if((n.isClickable()||n.isFocusable())&&!danger(label)){Rect r=new Rect();n.getBoundsInScreen(r);if(r.width()>12&&r.height()>12)out.add(new Action(r.centerX(),r.centerY(),"node"));}for(int i=0;i<n.getChildCount();i++)walk(n.getChild(i),out);}
    private boolean danger(String s){String[] bad={"buy","purchase","pay","subscribe","store","checkout","شراء","دفع","اشتراك","متجر","login","sign in","تسجيل الدخول","permission","إذن"};for(String b:bad)if(s.contains(b))return true;return false;}
    private int rewardHint(){AccessibilityNodeInfo r=getRootInActiveWindow();if(r==null)return 0;StringBuilder b=new StringBuilder();collectText(r,b);String s=b.toString().toLowerCase(Locale.ROOT);String[] good={"reward","claim","win","victory","coin","bonus","level complete","مكافأة","استلام","فوز","عملة","مستوى مكتمل"};for(String x:good)if(s.contains(x))return 45;return 0;}
    private void collectText(AccessibilityNodeInfo n,StringBuilder b){if(n==null||b.length()>3000)return;if(n.getText()!=null)b.append(' ').append(n.getText());if(n.getContentDescription()!=null)b.append(' ').append(n.getContentDescription());for(int i=0;i<n.getChildCount();i++)collectText(n.getChild(i),b);}
    private Action bestAction(JSONObject s){if(s==null)return null;JSONArray a=s.optJSONArray("actions");if(a==null)return null;JSONObject best=null;int score=-999;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null){int q=(int)Math.round(o.optDouble("avg",o.optInt("score",0)));if(q>score){score=q;best=o;}}}return best==null?null:Action.from(best);}
    private boolean seen(JSONArray arr,Action a){for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o!=null&&Math.abs(o.optInt("x")-a.x)<dp(18)&&Math.abs(o.optInt("y")-a.y)<dp(18))return true;}return false;}
    private void doAction(Action a,Runnable done){Path p=new Path();p.moveTo(a.x,a.y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,75)).build();boolean ok=dispatchGesture(g,new GestureResultCallback(){@Override public void onCompleted(GestureDescription gd){done.run();}@Override public void onCancelled(GestureDescription gd){done.run();}},h);if(!ok)h.postDelayed(done,120);}
    private interface CB{void got(String s);}
    private void capture(final CB cb){
        if(Build.VERSION.SDK_INT<30){cb.got("");return;}
        final Executor ex=getMainExecutor();
        takeScreenshot(Display.DEFAULT_DISPLAY,ex,new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult result){
                HardwareBuffer buffer=null; Bitmap wrapped=null; Bitmap copy=null; String sig="";
                try{
                    buffer=result.getHardwareBuffer();
                    wrapped=Bitmap.wrapHardwareBuffer(buffer,result.getColorSpace());
                    if(wrapped!=null){copy=wrapped.copy(Bitmap.Config.ARGB_8888,false);}
                    if(copy!=null){sig=signature(copy);}
                }catch(Exception ignored){}
                finally{
                    if(copy!=null)copy.recycle();
                    if(wrapped!=null)wrapped.recycle();
                    if(buffer!=null)try{buffer.close();}catch(Exception ignored){}
                }
                cb.got(sig);
            }
            @Override public void onFailure(int errorCode){cb.got("");}
        });
    }
    private String signature(Bitmap b){byte[] o=new byte[100];int w=b.getWidth(),hh=b.getHeight();for(int gy=0;gy<10;gy++)for(int gx=0;gx<10;gx++){int x=(int)(w*(.08+.84*(gx+.5)/10)),y=(int)(hh*(.12+.78*(gy+.5)/10));int c=b.getPixel(Math.min(w-1,x),Math.min(hh-1,y));o[gy*10+gx]=(byte)((Color.red(c)*30+Color.green(c)*59+Color.blue(c)*11)/100);}return Base64.encodeToString(o,Base64.NO_WRAP);}
    private int distance(String a,String b){if(a==null||b==null||a.isEmpty()||b.isEmpty())return 0;try{byte[] x=Base64.decode(a,0),y=Base64.decode(b,0);int z=0;for(int i=0;i<Math.min(x.length,y.length);i++)z+=Math.abs((x[i]&255)-(y[i]&255));return z/Math.max(1,Math.min(x.length,y.length));}catch(Exception e){return 0;}}
    private String stateKey(String s){if(s==null||s.isEmpty())return "unknown";try{byte[] a=Base64.decode(s,0);StringBuilder b=new StringBuilder();for(int i=0;i<a.length;i+=5)b.append(Integer.toHexString((a[i]&255)/32));return b.toString();}catch(Exception e){return "unknown";}}
    private void remember(){String n=pkg;try{ApplicationInfo a=getPackageManager().getApplicationInfo(pkg,0);n=getPackageManager().getApplicationLabel(a).toString();}catch(Exception ignored){}ProfileStore.ensureGame(this,pkg,n);}
    private String gameName(){if(!valid())return "افتح لعبة أولًا";try{ApplicationInfo a=getPackageManager().getApplicationInfo(pkg,0);return getPackageManager().getApplicationLabel(a).toString();}catch(Exception e){return pkg;}}
    private boolean valid(){return pkg!=null&&!pkg.isEmpty()&&!pkg.equals(getPackageName())&&!pkg.startsWith("com.android.systemui");}
    private void stop(){discovering=false;playing=false;h.removeCallbacksAndMessages(null);rmPanel();}
    private void rmPanel(){if(panel!=null){rm(panel);panel=null;}}
    private void rm(View v){if(v!=null&&wm!=null)try{wm.removeViewImmediate(v);}catch(Exception ignored){}}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setAllCaps(false);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(88,74,255),Color.rgb(0,166,255)});g.setCornerRadius(dp(15));b.setBackground(g);return b;}
    private TextView txt(String s,int z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);if(bold)t.setTypeface(null,1);return t;} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams blp(){LinearLayout.LayoutParams p=lp(dp(250),dp(54));p.topMargin=dp(8);return p;}private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private static final class Action{final int x,y;final String type;Action(int x,int y,String t){this.x=x;this.y=y;type=t;}JSONObject json(){JSONObject o=new JSONObject();try{o.put("x",x);o.put("y",y);o.put("type",type);}catch(Exception ignored){}return o;}static Action from(JSONObject o){return new Action(o.optInt("x"),o.optInt("y"),o.optString("type","learned"));}}
}
