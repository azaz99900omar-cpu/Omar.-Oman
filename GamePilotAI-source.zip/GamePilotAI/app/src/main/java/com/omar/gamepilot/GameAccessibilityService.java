package com.omar.gamepilot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;

public class GameAccessibilityService extends AccessibilityService {
    private WindowManager wm;
    private TextView bubble;
    private LinearLayout panel;
    private WindowManager.LayoutParams bubbleLp;
    private WindowManager.LayoutParams panelLp;
    private TrainingView trainingView;
    private WindowManager.LayoutParams trainingLp;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private String currentPackage = "";
    private boolean training = false;
    private boolean autoRunning = false;
    private JSONArray trainingActions = new JSONArray();
    private long lastTrainingActionEnd = 0L;
    private int autoIndex = 0;
    private int mismatchRetries = 0;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createBubble();
        toast("GamePilot AI جاهز. افتح لعبة واضغط زر AI.");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (pkg.equals(getPackageName())) {
            currentPackage = pkg;
            setBubbleVisible(false);
            return;
        }
        if (pkg.startsWith("com.android.systemui") || pkg.startsWith("com.google.android.permissioncontroller")) return;
        currentPackage = pkg;
        if (!training) setBubbleVisible(true);
    }

    @Override
    public void onInterrupt() {
        stopEverything();
    }

    @Override
    public void onDestroy() {
        stopEverything();
        removeViewSafe(panel);
        removeViewSafe(bubble);
        super.onDestroy();
    }

    private void createBubble() {
        if (bubble != null) return;
        bubble = new TextView(this);
        bubble.setText("AI");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(16);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(77, 95, 255));
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(2), Color.argb(150, 255, 255, 255));
        bubble.setBackground(bg);
        bubble.setElevation(dp(8));
        bubble.setOnClickListener(v -> togglePanel());

        bubbleLp = new WindowManager.LayoutParams(
                dp(58), dp(58), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        bubbleLp.x = dp(10);
        bubbleLp.y = 0;
        wm.addView(bubble, bubbleLp);
    }

    private void togglePanel() {
        if (panel != null) {
            removeViewSafe(panel);
            panel = null;
            return;
        }
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(245, 22, 28, 42));
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.argb(90, 255, 255, 255));
        panel.setBackground(bg);
        panel.setElevation(dp(12));

        TextView label = new TextView(this);
        label.setText("GamePilot AI\n" + shortPackage());
        label.setTextColor(Color.WHITE);
        label.setTextSize(13);
        label.setGravity(Gravity.CENTER);
        panel.addView(label, new LinearLayout.LayoutParams(dp(190), dp(54)));

        Button register = menuButton("تسجيل اللعبة");
        register.setOnClickListener(v -> registerCurrentGame(true));
        panel.addView(register, menuLp());

        Button train = menuButton("تدريب");
        train.setOnClickListener(v -> startTraining());
        panel.addView(train, menuLp());

        Button play = menuButton("تشغيل تلقائي");
        play.setOnClickListener(v -> startAuto());
        panel.addView(play, menuLp());

        Button stop = menuButton("إيقاف");
        stop.setOnClickListener(v -> {
            stopEverything();
            toast("تم الإيقاف");
        });
        panel.addView(stop, menuLp());

        panelLp = new WindowManager.LayoutParams(
                dp(214), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        panelLp.x = dp(78);
        panelLp.y = 0;
        wm.addView(panel, panelLp);
    }

    private LinearLayout.LayoutParams menuLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(190), dp(46));
        lp.topMargin = dp(6);
        return lp;
    }

    private Button menuButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(47, 58, 84));
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        return b;
    }

    private void registerCurrentGame(boolean notify) {
        if (!validGamePackage()) {
            toast("افتح اللعبة أولًا ثم اضغط زر AI.");
            return;
        }
        if (ProfileStore.hasProfile(this, currentPackage)) {
            if (notify) toast("هذه اللعبة مسجلة بالفعل ويمكنك استخدامها مباشرة.");
            return;
        }
        String name = currentPackage;
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(currentPackage, 0);
            CharSequence label = getPackageManager().getApplicationLabel(ai);
            if (label != null) name = label.toString();
        } catch (Exception ignored) {}
        ProfileStore.addProfile(this, currentPackage, name);
        if (notify) toast("تم تسجيل اللعبة: " + name);
    }

    private void startTraining() {
        stopEverything();
        if (!validGamePackage()) {
            toast("افتح اللعبة أولًا.");
            return;
        }
        registerCurrentGame(false);
        trainingActions = new JSONArray();
        lastTrainingActionEnd = System.currentTimeMillis();
        training = true;
        removePanel();
        setBubbleVisible(false);
        addTrainingOverlay();
        toast("بدأ التدريب. العب بنفسك، ثم اضغط «إنهاء التدريب» أعلى الشاشة.");
    }

    private void addTrainingOverlay() {
        if (!training || trainingView != null) return;
        trainingView = new TrainingView(this);
        trainingLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        trainingLp.gravity = Gravity.TOP | Gravity.START;
        try { wm.addView(trainingView, trainingLp); } catch (Exception ignored) {}
    }

    private void temporarilyRemoveTrainingOverlay() {
        if (trainingView != null) {
            removeViewSafe(trainingView);
            trainingView = null;
        }
    }

    private void handleTrainingGesture(float x1, float y1, float x2, float y2, long duration, long downWallTime) {
        if (!training) return;
        long delay = Math.max(0, downWallTime - lastTrainingActionEnd);
        temporarilyRemoveTrainingOverlay();
        handler.postDelayed(() -> captureSignature(sig -> {
            if (!training) return;
            JSONObject action = new JSONObject();
            try {
                action.put("x1", Math.round(x1));
                action.put("y1", Math.round(y1));
                action.put("x2", Math.round(x2));
                action.put("y2", Math.round(y2));
                action.put("duration", Math.max(45, Math.min(duration, 4000)));
                action.put("delay", Math.min(delay, 8000));
                action.put("sig", sig == null ? "" : sig);
                trainingActions.put(action);
                ProfileStore.saveActions(this, currentPackage, trainingActions);
            } catch (JSONException ignored) {}

            dispatchRecordedGesture(action, () -> {
                lastTrainingActionEnd = System.currentTimeMillis();
                if (training) handler.postDelayed(this::addTrainingOverlay, 70);
            });
        }), 55);
    }

    private void stopTraining() {
        if (!training) return;
        training = false;
        temporarilyRemoveTrainingOverlay();
        ProfileStore.saveActions(this, currentPackage, trainingActions);
        setBubbleVisible(true);
        toast("انتهى التدريب وحُفظت " + trainingActions.length() + " حركة.");
    }

    private void startAuto() {
        stopEverything();
        if (!validGamePackage()) {
            toast("افتح اللعبة المسجلة أولًا.");
            return;
        }
        JSONArray actions = ProfileStore.loadActions(this, currentPackage);
        if (actions.length() == 0) {
            toast("هذه اللعبة لا تحتوي تدريبًا بعد. اختر «تدريب» أولًا.");
            return;
        }
        autoRunning = true;
        autoIndex = 0;
        mismatchRetries = 0;
        removePanel();
        setBubbleVisible(true);
        toast("بدأ التشغيل التلقائي. اضغط AI ثم «إيقاف» متى شئت.");
        handler.postDelayed(() -> autoStep(actions), 700);
    }

    private void autoStep(JSONArray actions) {
        if (!autoRunning || actions.length() == 0) return;
        if (autoIndex >= actions.length()) {
            autoIndex = 0;
            mismatchRetries = 0;
            handler.postDelayed(() -> autoStep(actions), 900);
            return;
        }
        JSONObject a = actions.optJSONObject(autoIndex);
        if (a == null) {
            autoIndex++;
            autoStep(actions);
            return;
        }
        long delay = Math.max(30, a.optLong("delay", 120));
        handler.postDelayed(() -> {
            if (!autoRunning) return;
            String expected = a.optString("sig", "");
            if (expected.isEmpty()) {
                runAutoAction(actions, a);
                return;
            }
            captureSignature(actual -> {
                if (!autoRunning) return;
                int distance = signatureDistance(expected, actual);
                if (actual != null && distance > 30 && mismatchRetries < 7) {
                    mismatchRetries++;
                    handler.postDelayed(() -> autoStepWithoutDelay(actions), 330);
                } else {
                    mismatchRetries = 0;
                    runAutoAction(actions, a);
                }
            });
        }, Math.min(delay, 8000));
    }

    private void autoStepWithoutDelay(JSONArray actions) {
        if (!autoRunning || autoIndex >= actions.length()) return;
        JSONObject a = actions.optJSONObject(autoIndex);
        if (a == null) { autoIndex++; autoStep(actions); return; }
        String expected = a.optString("sig", "");
        captureSignature(actual -> {
            if (!autoRunning) return;
            int distance = signatureDistance(expected, actual);
            if (actual != null && !expected.isEmpty() && distance > 30 && mismatchRetries < 7) {
                mismatchRetries++;
                handler.postDelayed(() -> autoStepWithoutDelay(actions), 330);
            } else {
                mismatchRetries = 0;
                runAutoAction(actions, a);
            }
        });
    }

    private void runAutoAction(JSONArray actions, JSONObject a) {
        dispatchRecordedGesture(a, () -> {
            if (!autoRunning) return;
            autoIndex++;
            handler.postDelayed(() -> autoStep(actions), 50);
        });
    }

    private void dispatchRecordedGesture(JSONObject a, Runnable done) {
        float x1 = (float) a.optDouble("x1", 0);
        float y1 = (float) a.optDouble("y1", 0);
        float x2 = (float) a.optDouble("x2", x1);
        float y2 = (float) a.optDouble("y2", y1);
        long duration = Math.max(45, a.optLong("duration", 80));

        Path p = new Path();
        p.moveTo(x1, y1);
        float dx = Math.abs(x2 - x1), dy = Math.abs(y2 - y1);
        if (dx + dy > dp(10)) p.lineTo(x2, y2);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p, 0, duration);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) { if (done != null) done.run(); }
            @Override public void onCancelled(GestureDescription gestureDescription) { if (done != null) done.run(); }
        }, handler);
        if (!accepted && done != null) handler.postDelayed(done, duration + 50);
    }

    private interface SignatureCallback { void onSignature(String signature); }

    private void captureSignature(SignatureCallback cb) {
        if (android.os.Build.VERSION.SDK_INT < 30) { cb.onSignature(null); return; }
        Executor executor = getMainExecutor();
        takeScreenshot(Display.DEFAULT_DISPLAY, executor, new TakeScreenshotCallback() {
            @Override
            public void onSuccess(ScreenshotResult screenshot) {
                HardwareBuffer hb = screenshot.getHardwareBuffer();
                Bitmap hardware = null;
                Bitmap copy = null;
                try {
                    hardware = Bitmap.wrapHardwareBuffer(hb, screenshot.getColorSpace());
                    if (hardware != null) copy = hardware.copy(Bitmap.Config.ARGB_8888, false);
                    cb.onSignature(copy == null ? null : makeSignature(copy));
                } catch (Exception e) {
                    cb.onSignature(null);
                } finally {
                    if (copy != null) copy.recycle();
                    if (hardware != null) hardware.recycle();
                    try { hb.close(); } catch (Exception ignored) {}
                }
            }

            @Override
            public void onFailure(int errorCode) {
                cb.onSignature(null);
            }
        });
    }

    private String makeSignature(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        if (w < 20 || h < 20) return "";
        byte[] out = new byte[64];
        int left = Math.round(w * 0.10f), right = Math.round(w * 0.82f);
        int top = Math.round(h * 0.12f), bottom = Math.round(h * 0.90f);
        for (int gy = 0; gy < 8; gy++) {
            for (int gx = 0; gx < 8; gx++) {
                int x = left + Math.round((right - left - 1) * (gx + 0.5f) / 8f);
                int y = top + Math.round((bottom - top - 1) * (gy + 0.5f) / 8f);
                int c = b.getPixel(Math.max(0, Math.min(w - 1, x)), Math.max(0, Math.min(h - 1, y)));
                int gray = (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100;
                out[gy * 8 + gx] = (byte) gray;
            }
        }
        return Base64.encodeToString(out, Base64.NO_WRAP);
    }

    private int signatureDistance(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return 0;
        try {
            byte[] aa = Base64.decode(a, Base64.NO_WRAP);
            byte[] bb = Base64.decode(b, Base64.NO_WRAP);
            int n = Math.min(aa.length, bb.length);
            if (n == 0) return 0;
            int sum = 0;
            for (int i = 0; i < n; i++) sum += Math.abs((aa[i] & 0xff) - (bb[i] & 0xff));
            return sum / n;
        } catch (Exception e) { return 0; }
    }

    private void stopEverything() {
        autoRunning = false;
        handler.removeCallbacksAndMessages(null);
        if (training) stopTraining();
        training = false;
        temporarilyRemoveTrainingOverlay();
        if (bubble != null) setBubbleVisible(true);
    }

    private void removePanel() {
        if (panel != null) {
            removeViewSafe(panel);
            panel = null;
        }
    }

    private boolean validGamePackage() {
        return currentPackage != null && !currentPackage.isEmpty()
                && !currentPackage.equals(getPackageName())
                && !currentPackage.startsWith("com.android.systemui");
    }

    private String shortPackage() {
        if (currentPackage == null || currentPackage.isEmpty()) return "افتح لعبة أولًا";
        if (currentPackage.length() <= 26) return currentPackage;
        return "…" + currentPackage.substring(currentPackage.length() - 25);
    }

    private void setBubbleVisible(boolean visible) {
        if (bubble == null) return;
        bubble.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (!visible) removePanel();
    }

    private void removeViewSafe(View v) {
        if (v == null || wm == null) return;
        try { wm.removeViewImmediate(v); } catch (Exception ignored) {}
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private final class TrainingView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF stopRect = new RectF();
        private float downX, downY, lastX, lastY;
        private long downElapsed, downWall;
        private boolean stopGesture = false;

        TrainingView(Context c) {
            super(c);
            setBackgroundColor(Color.TRANSPARENT);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float pad = dp(12);
            float barH = dp(54);
            stopRect.set(pad, pad, Math.min(getWidth() - pad, dp(190)), pad + barH);
            paint.setColor(Color.argb(225, 190, 45, 65));
            canvas.drawRoundRect(stopRect, dp(16), dp(16), paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(dp(16));
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            canvas.drawText("إنهاء التدريب", stopRect.centerX(), stopRect.centerY() + dp(6), paint);

            paint.setColor(Color.argb(180, 12, 18, 28));
            RectF badge = new RectF(getWidth() - dp(150), pad, getWidth() - pad, pad + barH);
            canvas.drawRoundRect(badge, dp(16), dp(16), paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(dp(13));
            canvas.drawText("AI يتعلم: " + trainingActions.length(), badge.centerX(), badge.centerY() + dp(5), paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (!training) return true;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = lastX = e.getX();
                    downY = lastY = e.getY();
                    downElapsed = e.getEventTime();
                    downWall = System.currentTimeMillis();
                    stopGesture = stopRect.contains(downX, downY);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    lastX = e.getX(); lastY = e.getY();
                    return true;
                case MotionEvent.ACTION_UP:
                    lastX = e.getX(); lastY = e.getY();
                    if (stopGesture && stopRect.contains(lastX, lastY)) {
                        stopTraining();
                        return true;
                    }
                    long duration = Math.max(45, e.getEventTime() - downElapsed);
                    handleTrainingGesture(downX, downY, lastX, lastY, duration, downWall);
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    return true;
            }
            return true;
        }
    }
}
