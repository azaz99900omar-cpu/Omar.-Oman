package com.omar.gamepilot;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class ProfileStore {
    private static final String PREFS = "gamepilot_store";
    private static final String PROFILES = "profiles";

    private ProfileStore() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized boolean hasProfile(Context c, String pkg) {
        return getProfilesJson(c).has(pkg);
    }

    public static synchronized void addProfile(Context c, String pkg, String name) {
        JSONObject root = getProfilesJson(c);
        try {
            JSONObject p = root.optJSONObject(pkg);
            if (p == null) p = new JSONObject();
            p.put("name", name == null || name.isEmpty() ? pkg : name);
            if (!p.has("created")) p.put("created", System.currentTimeMillis());
            root.put(pkg, p);
            prefs(c).edit().putString(PROFILES, root.toString()).apply();
        } catch (JSONException ignored) {}
    }

    public static synchronized List<GameProfile> listProfiles(Context c) {
        JSONObject root = getProfilesJson(c);
        List<GameProfile> out = new ArrayList<>();
        JSONArray names = root.names();
        if (names == null) return out;
        for (int i = 0; i < names.length(); i++) {
            String pkg = names.optString(i);
            JSONObject p = root.optJSONObject(pkg);
            String name = p == null ? pkg : p.optString("name", pkg);
            int actions = loadActions(c, pkg).length();
            out.add(new GameProfile(pkg, name, actions));
        }
        return out;
    }

    private static JSONObject getProfilesJson(Context c) {
        try {
            return new JSONObject(prefs(c).getString(PROFILES, "{}"));
        } catch (JSONException e) {
            return new JSONObject();
        }
    }

    public static synchronized JSONArray loadActions(Context c, String pkg) {
        try {
            return new JSONArray(prefs(c).getString("actions_" + pkg, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    public static synchronized void saveActions(Context c, String pkg, JSONArray actions) {
        prefs(c).edit().putString("actions_" + pkg, actions.toString()).apply();
    }

    public static final class GameProfile {
        public final String packageName;
        public final String name;
        public final int actionCount;

        public GameProfile(String packageName, String name, int actionCount) {
            this.packageName = packageName;
            this.name = name;
            this.actionCount = actionCount;
        }
    }
}
