package com.omar.gamepilot;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout gamesContainer;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 21, 34));
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(16, 21, 34));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        TextView title = text("GamePilot AI 2.0", 30, Color.WHITE, true);
        root.addView(title);

        TextView sub = text("مساعد ألعاب عائم مطوّر: تدريب، تشغيل ذكي، إيقاف مؤقت، تكرار، ومقارنة بصرية لحالة الشاشة.", 16, Color.rgb(184, 195, 218), false);
        LinearLayout.LayoutParams subLp = lp(-1, -2); subLp.topMargin = dp(6); subLp.bottomMargin = dp(18);
        root.addView(sub, subLp);

        LinearLayout serviceCard = card();
        status = text("", 17, Color.WHITE, true);
        serviceCard.addView(status);

        TextView explain = text("يحتاج التطبيق إلى خدمة تسهيل الاستخدام لعرض زر AI فوق اللعبة وتنفيذ اللمسات التي درّبتها. لا يتم إرسال تسجيل اللعب إلى خادم في هذه النسخة.", 14, Color.rgb(190, 198, 216), false);
        LinearLayout.LayoutParams eLp = lp(-1, -2); eLp.topMargin = dp(8); eLp.bottomMargin = dp(12);
        serviceCard.addView(explain, eLp);

        Button enable = button("تفعيل التحكم بالشاشة");
        enable.setOnClickListener(v -> showDisclosureThenSettings());
        serviceCard.addView(enable, lp(-1, dp(52)));
        root.addView(serviceCard);

        TextView how = text("طريقة الاستخدام", 20, Color.WHITE, true);
        LinearLayout.LayoutParams howLp = lp(-1, -2); howLp.topMargin = dp(22); howLp.bottomMargin = dp(8);
        root.addView(how, howLp);

        TextView steps = text("1) فعّل خدمة التحكم.  2) افتح اللعبة.  3) اضغط زر AI العائم واختر «تسجيل اللعبة».  4) اختر «تدريب» والعب بنفسك.  5) اضغط «إنهاء التدريب».  6) بعد ذلك اختر «تشغيل تلقائي».", 15, Color.rgb(210, 216, 230), false);
        steps.setLineSpacing(dp(3), 1f);
        root.addView(steps);

        TextView gamesTitle = text("الألعاب المسجلة", 20, Color.WHITE, true);
        LinearLayout.LayoutParams gtLp = lp(-1, -2); gtLp.topMargin = dp(24); gtLp.bottomMargin = dp(8);
        root.addView(gamesTitle, gtLp);

        gamesContainer = new LinearLayout(this);
        gamesContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(gamesContainer, lp(-1, -2));

        TextView note = text("الإصدار 2.0: الزر العائم قابل للسحب ولا يختفي عند الضغط، مع لوحة تحكم أوضح وحالة تدريب وتشغيل ذكي محسّنة. الأداء يعتمد على ثبات واجهة اللعبة وجودة التدريب.", 13, Color.rgb(151, 164, 190), false);
        LinearLayout.LayoutParams nLp = lp(-1, -2); nLp.topMargin = dp(22);
        root.addView(note, nLp);

        setContentView(scroll);
    }

    private void refresh() {
        boolean enabled = isAccessibilityEnabled();
        status.setText(enabled ? "● التحكم بالشاشة: مفعّل" : "○ التحكم بالشاشة: غير مفعّل");
        status.setTextColor(enabled ? Color.rgb(100, 230, 170) : Color.rgb(255, 184, 100));

        gamesContainer.removeAllViews();
        List<ProfileStore.GameProfile> profiles = ProfileStore.listProfiles(this);
        if (profiles.isEmpty()) {
            TextView empty = text("لا توجد ألعاب مسجلة بعد. افتح أي لعبة واستخدم زر AI العائم لإضافتها.", 14, Color.rgb(170, 181, 203), false);
            gamesContainer.addView(empty);
            return;
        }
        for (ProfileStore.GameProfile p : profiles) {
            LinearLayout row = card();
            TextView name = text(p.name, 17, Color.WHITE, true);
            row.addView(name);
            TextView meta = text(p.packageName + "\n" + p.actionCount + " حركة تدريبية", 12, Color.rgb(160, 174, 199), false);
            LinearLayout.LayoutParams mlp = lp(-1, -2); mlp.topMargin = dp(4); mlp.bottomMargin = dp(10);
            row.addView(meta, mlp);
            Button open = button("فتح اللعبة");
            open.setOnClickListener(v -> launchPackage(p.packageName));
            row.addView(open, lp(-1, dp(48)));
            LinearLayout.LayoutParams rlp = lp(-1, -2); rlp.bottomMargin = dp(10);
            gamesContainer.addView(row, rlp);
        }
    }

    private void showDisclosureThenSettings() {
        new AlertDialog.Builder(this)
                .setTitle("إذن التحكم بالشاشة")
                .setMessage("عند تفعيل الخدمة، يستطيع GamePilot AI معرفة التطبيق المفتوح، التقاط صور للشاشة أثناء التدريب، وعرض زر عائم وتنفيذ اللمسات التي سجّلتها. البيانات تبقى محليًا في هذه النسخة. فعّل الخدمة فقط إذا كنت موافقًا على ذلك.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("أوافق وأفتح الإعدادات", (d, w) -> {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                }).show();
    }

    private void launchPackage(String pkg) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setPackage(pkg);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح اللعبة تلقائيًا. افتحها يدويًا ثم استخدم زر AI.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isAccessibilityEnabled() {
        ComponentName cn = new ComponentName(this, GameAccessibilityService.class);
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            ComponentName c = ComponentName.unflattenFromString(splitter.next());
            if (cn.equals(c)) return true;
        }
        return false;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(27, 35, 53));
        bg.setCornerRadius(dp(18));
        c.setBackground(bg);
        return c;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(77, 95, 255));
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        return b;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
