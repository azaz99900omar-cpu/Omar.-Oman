# GamePilot AI — Android prototype

Native Android app (Java, no external libraries) for learning a game by demonstration and replaying the recorded actions.

## What v0.1 does
- User explicitly enables an Accessibility Service.
- A floating `AI` button appears above other apps.
- `Register game` stores the currently open app as a game profile.
- Duplicate registration is detected.
- `Train` places a transparent training layer over the game. User taps/swipes normally; the app records coordinates, timing, and a compact 8x8 visual screen signature, then forwards each gesture to the game.
- `Auto play` replays the learned gesture sequence and compares the live screen signature to the learned state before each step, waiting briefly when the screen is not ready.
- Profiles and training data are stored locally in SharedPreferences.

## Current limitations
- Android 12 / API 31 or newer.
- One-finger taps, long presses, and simple swipes only.
- This is adaptive imitation, not a universal reinforcement-learning agent. Games with random layouts, 3D joystick control, multi-touch, anti-bot systems, CAPTCHAs, or rapidly changing scenes may not replay reliably.
- Some games use secure windows that block screenshots; replay still works but visual state matching may be unavailable.
- Do not use it to bypass anti-cheat or game security controls. Use only where the game's rules permit automation.

## Build
The included GitHub Actions workflow builds a debug APK automatically on push to `main` or manually via `workflow_dispatch`.

Local build requirements: JDK 17, Android SDK 35, Gradle 8.9.

```bash
gradle assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Google Play note
This prototype uses AccessibilityService for user-defined automation. Google Play has strict Accessibility API policies. Review the current policy before any Play Store release; sideload/internal testing is the simplest route for this prototype.
