package com.omar.gamepilot;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class ProfileStore {
    private static final String PREFS="gamepilot_store";
    private static SharedPreferences p(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    private ProfileStore(){}
    public static synchronized void ensureGame(Context c,String pkg,String name){
        try{JSONObject r=new JSONObject(p(c).getString("profiles","{}")); JSONObject g=r.optJSONObject(pkg); if(g==null)g=new JSONObject(); g.put("name",name); if(!g.has("created"))g.put("created",System.currentTimeMillis()); r.put(pkg,g); p(c).edit().putString("profiles",r.toString()).apply();}catch(Exception ignored){}
    }
    public static synchronized JSONObject loadBrain(Context c,String pkg){try{return new JSONObject(p(c).getString("brain_"+pkg,"{}"));}catch(Exception e){return new JSONObject();}}
    public static synchronized void saveBrain(Context c,String pkg,JSONObject brain){p(c).edit().putString("brain_"+pkg,brain.toString()).apply();}
    public static synchronized int learnedStates(Context c,String pkg){return loadBrain(c,pkg).length();}
    public static synchronized List<GameProfile> listProfiles(Context c){
        List<GameProfile> out=new ArrayList<>(); try{JSONObject r=new JSONObject(p(c).getString("profiles","{}")); JSONArray n=r.names(); if(n==null)return out; for(int i=0;i<n.length();i++){String pkg=n.optString(i); JSONObject g=r.optJSONObject(pkg); out.add(new GameProfile(pkg,g==null?pkg:g.optString("name",pkg),learnedStates(c,pkg)));}}catch(Exception ignored){} return out;
    }
    // Compatibility with v2 data.
    public static synchronized boolean hasProfile(Context c,String pkg){for(GameProfile g:listProfiles(c))if(g.packageName.equals(pkg))return true;return false;}
    public static synchronized void addProfile(Context c,String pkg,String name){ensureGame(c,pkg,name);}
    public static synchronized JSONArray loadActions(Context c,String pkg){try{return new JSONArray(p(c).getString("actions_"+pkg,"[]"));}catch(JSONException e){return new JSONArray();}}
    public static synchronized void saveActions(Context c,String pkg,JSONArray a){p(c).edit().putString("actions_"+pkg,a.toString()).apply();}
    public static final class GameProfile{public final String packageName,name; public final int actionCount; public GameProfile(String p,String n,int s){packageName=p;name=n;actionCount=s;}}
}
