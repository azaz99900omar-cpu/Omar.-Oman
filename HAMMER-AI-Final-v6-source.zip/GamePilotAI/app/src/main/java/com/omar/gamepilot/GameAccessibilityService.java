package com.omar.gamepilot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.pm.ApplicationInfo;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.util.Base64;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.Executor;

public class GameAccessibilityService extends AccessibilityService {
    private WindowManager wm; private TextView bubble; private LinearLayout panel; private WindowManager.LayoutParams bubbleLp;
    private final Handler h=new Handler(Looper.getMainLooper()); private String pkg=""; private boolean discovering=false,playing=false; private int step=0,stuck=0; private String lastSig=""; private float dx,dy; private int sx,sy; private AnimatorSet pulse;
    private final Random rng=new Random();

    @Override protected void onServiceConnected(){wm=(WindowManager)getSystemService(WINDOW_SERVICE);createBubble();toast("HAMMER AI جاهز");}
    @Override public void onAccessibilityEvent(AccessibilityEvent e){if(e.getPackageName()==null)return;String p=e.getPackageName().toString();if(p.equals(getPackageName())||p.startsWith("com.android.systemui")||p.contains("permissioncontroller"))return;pkg=p;}
    @Override public void onInterrupt(){stop();}
    @Override public void onDestroy(){stop();rm(panel);rm(bubble);super.onDestroy();}

    private void createBubble(){
        bubble=new TextView(this);bubble.setText("🔨\nAI");bubble.setTextColor(Color.WHITE);bubble.setTextSize(13);bubble.setGravity(Gravity.CENTER);bubble.setTypeface(null,1);bubble.setElevation(dp(18));
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(115,64,255),Color.rgb(0,204,230)});g.setShape(GradientDrawable.OVAL);g.setStroke(dp(2),Color.argb(210,255,255,255));bubble.setBackground(g);
        bubbleLp=new WindowManager.LayoutParams(dp(68),dp(68),WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);bubbleLp.gravity=Gravity.END|Gravity.CENTER_VERTICAL;bubbleLp.x=dp(10);wm.addView(bubble,bubbleLp);
        bubble.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){dx=e.getRawX();dy=e.getRawY();sx=bubbleLp.x;sy=bubbleLp.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){if(Math.abs(e.getRawX()-dx)+Math.abs(e.getRawY()-dy)>dp(8)){bubbleLp.x=Math.max(0,sx-Math.round(e.getRawX()-dx));bubbleLp.y=sy+Math.round(e.getRawY()-dy);try{wm.updateViewLayout(bubble,bubbleLp);}catch(Exception ignored){}}return true;}if(e.getAction()==MotionEvent.ACTION_UP){if(Math.abs(e.getRawX()-dx)+Math.abs(e.getRawY()-dy)<dp(14))togglePanel();return true;}return true;});
        ObjectAnimator a=ObjectAnimator.ofFloat(bubble,View.ALPHA,.78f,1f,.78f),x=ObjectAnimator.ofFloat(bubble,View.SCALE_X,1f,1.12f,1f),y=ObjectAnimator.ofFloat(bubble,View.SCALE_Y,1f,1.12f,1f);for(ObjectAnimator q:new ObjectAnimator[]{a,x,y}){q.setDuration(1450);q.setRepeatCount(-1);}pulse=new AnimatorSet();pulse.playTogether(a,x,y);pulse.start();
    }
    private void togglePanel(){if(discovering||playing){stop();toast("تم إيقاف HAMMER AI");return;}if(panel!=null){rm(panel);panel=null;return;}panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(14),dp(14),dp(14),dp(14));GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(16,22,43),Color.rgb(34,30,72)});bg.setCornerRadius(dp(22));bg.setStroke(dp(1),Color.argb(100,120,220,255));panel.setBackground(bg);panel.setElevation(dp(18));
        TextView title=txt("🔨 HAMMER AI",20,true);title.setGravity(Gravity.CENTER);panel.addView(title,lp(dp(252),dp(46)));
        TextView state=txt("جاهز • "+gameName()+"\n"+ProfileStore.learnedStates(this,pkg)+" حالة متعلّمة",12,false);state.setTextColor(Color.rgb(180,215,240));state.setGravity(Gravity.CENTER);panel.addView(state,lp(dp(252),dp(56)));
        Button learn=button("🧠  اكتشف وتعلّم");learn.setOnClickListener(v->startDiscover());panel.addView(learn,blp());
        Button play=button("🎮  العب عني");play.setOnClickListener(v->startPlay());panel.addView(play,blp());
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(280),-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);p.gravity=Gravity.END|Gravity.CENTER_VERTICAL;p.x=dp(84);wm.addView(panel,p);
    }
    private void startDiscover(){stop();if(!valid()){toast("افتح اللعبة أولًا");return;}remember();discovering=true;stuck=0;lastSig="";rmPanel();toast("HAMMER AI بدأ الاستكشاف والتعلّم");h.postDelayed(this::discoverLoop,550);}
    private void startPlay(){stop();if(!valid()){toast("افتح اللعبة أولًا");return;}remember();if(ProfileStore.learnedStates(this,pkg)==0){toast("شغّل «اكتشف وتعلّم» أولًا");return;}playing=true;stuck=0;lastSig="";rmPanel();toast("HAMMER AI يلعب عنك الآن");h.postDelayed(this::playLoop,450);}

    private void discoverLoop(){
        if(!discovering||!valid())return;
        capture(sig->{
            if(!discovering)return;
            final JSONObject brain=ProfileStore.loadBrain(this,pkg);final String key=stateKey(sig);
            JSONObject st=brain.optJSONObject(key);if(st==null)st=new JSONObject();final JSONObject state=st;
            JSONArray aa=state.optJSONArray("actions");if(aa==null)aa=new JSONArray();final JSONArray actions=aa;
            final Action action=chooseLearningAction(state,actions);final String before=sig;
            doAction(action,()->h.postDelayed(()->capture(after->{
                int change=distance(before,after);int reward=rewardHint()+Math.min(65,change)+(change>7?12:-10);
                if(action.type.equals("sequence")&&change>7)reward+=8;if(action.type.equals("swipe")&&change>10)reward+=6;
                updateActionKnowledge(actions,action,reward,change);
                try{state.put("actions",actions);state.put("visits",state.optInt("visits",0)+1);state.put("lastReward",reward);state.put("lastChange",change);brain.put(key,state);ProfileStore.saveBrain(this,pkg,brain);}catch(Exception ignored){}
                step++;stuck=change<4?stuck+1:0;lastSig=after;h.postDelayed(this::discoverLoop,stuck>3?250:520);
            }),action.settleMs));
        });
    }
    private void playLoop(){
        if(!playing||!valid())return;
        capture(sig->{
            JSONObject brain=ProfileStore.loadBrain(this,pkg);JSONObject state=brain.optJSONObject(stateKey(sig));Action action=bestAction(state);
            if(action==null||stuck>4)action=chooseFallback();final Action selected=action;final String before=sig;
            doAction(selected,()->h.postDelayed(()->capture(after->{int change=distance(before,after);stuck=change<3?stuck+1:0;lastSig=after;h.postDelayed(this::playLoop,stuck>4?180:380);}),selected.settleMs));
        });
    }

    private Action chooseLearningAction(JSONObject state,JSONArray actions){
        List<Action> candidates=allCandidates();for(Action a:candidates)if(!seen(actions,a))return a;
        int total=Math.max(1,state.optInt("visits",1));double best=-1e9;Action pick=candidates.isEmpty()?chooseFallback():candidates.get(0);
        for(Action a:candidates){JSONObject rec=findAction(actions,a);double avg=rec==null?0:rec.optDouble("avg",0);int n=rec==null?0:rec.optInt("tries",0);double ucb=avg+24.0*Math.sqrt(Math.log(total+2.0)/(n+1.0));if(ucb>best){best=ucb;pick=a;}}
        return pick;
    }
    private List<Action> allCandidates(){List<Action> out=nodeActions();int w=getResources().getDisplayMetrics().widthPixels,hh=getResources().getDisplayMetrics().heightPixels;
        int l=(int)(w*.18),r=(int)(w*.82),cx=w/2,t=(int)(hh*.25),cy=(int)(hh*.55),b=(int)(hh*.82);
        out.add(Action.tap(cx,cy));out.add(Action.tap(l,cy));out.add(Action.tap(r,cy));
        out.add(Action.swipe(cx,b,cx,t,280));out.add(Action.swipe(cx,t,cx,b,280));out.add(Action.swipe(r,cy,l,cy,260));out.add(Action.swipe(l,cy,r,cy,260));
        out.add(Action.sequence(l,cy,r,cy,85));out.add(Action.sequence(r,cy,l,cy,85));out.add(Action.sequence(l,b,r,b,70));out.add(Action.sequence(r,b,l,b,70));
        return out;
    }
    private Action chooseFallback(){List<Action> c=allCandidates();return c.get(Math.abs(rng.nextInt())%c.size());}
    private JSONObject findAction(JSONArray arr,Action a){for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o!=null&&same(o,a))return o;}return null;}
    private boolean same(JSONObject o,Action a){return o.optString("type","tap").equals(a.type)&&Math.abs(o.optInt("x")-a.x)<dp(20)&&Math.abs(o.optInt("y")-a.y)<dp(20)&&Math.abs(o.optInt("x2")-a.x2)<dp(25)&&Math.abs(o.optInt("y2")-a.y2)<dp(25);}
    private void updateActionKnowledge(JSONArray arr,Action a,int reward,int change){try{JSONObject rec=findAction(arr,a);if(rec==null){rec=a.json();rec.put("tries",0);rec.put("avg",0.0);arr.put(rec);}int n=rec.optInt("tries",0)+1;double avg=rec.optDouble("avg",0.0);avg+=((double)reward-avg)/n;rec.put("tries",n);rec.put("avg",avg);rec.put("score",(int)Math.round(avg));rec.put("change",change);rec.put("success",change>6);}catch(Exception ignored){}}
    private List<Action> nodeActions(){List<Action> out=new ArrayList<>();AccessibilityNodeInfo r=getRootInActiveWindow();if(r!=null)walk(r,out);return out;}
    private void walk(AccessibilityNodeInfo n,List<Action> out){if(n==null||out.size()>22)return;CharSequence t=n.getText(),d=n.getContentDescription();String label=((t==null?"":t.toString())+" "+(d==null?"":d.toString())).toLowerCase(Locale.ROOT);if((n.isClickable()||n.isFocusable())&&!danger(label)){Rect r=new Rect();n.getBoundsInScreen(r);if(r.width()>12&&r.height()>12)out.add(Action.tap(r.centerX(),r.centerY()));}for(int i=0;i<n.getChildCount();i++)walk(n.getChild(i),out);}
    private boolean danger(String s){String[] bad={"buy","purchase","pay","subscribe","checkout","شراء","دفع","اشتراك","login","sign in","تسجيل الدخول","permission","إذن","delete account","حذف الحساب"};for(String b:bad)if(s.contains(b))return true;return false;}
    private int rewardHint(){AccessibilityNodeInfo r=getRootInActiveWindow();if(r==null)return 0;StringBuilder b=new StringBuilder();collectText(r,b);String s=b.toString().toLowerCase(Locale.ROOT);String[] good={"reward","claim","win","victory","coin","bonus","level complete","next level","مكافأة","استلام","فوز","عملة","مستوى مكتمل","التالي"};for(String x:good)if(s.contains(x))return 45;return 0;}
    private void collectText(AccessibilityNodeInfo n,StringBuilder b){if(n==null||b.length()>3500)return;if(n.getText()!=null)b.append(' ').append(n.getText());if(n.getContentDescription()!=null)b.append(' ').append(n.getContentDescription());for(int i=0;i<n.getChildCount();i++)collectText(n.getChild(i),b);}
    private Action bestAction(JSONObject s){if(s==null)return null;JSONArray a=s.optJSONArray("actions");if(a==null)return null;JSONObject best=null;double score=-999;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null){double q=o.optDouble("avg",o.optInt("score",0));int tries=o.optInt("tries",0);if(tries>0&&q>score){score=q;best=o;}}}return best==null?null:Action.from(best);}
    private boolean seen(JSONArray arr,Action a){return findAction(arr,a)!=null;}

    private void doAction(Action a,Runnable done){
        if(a==null){done.run();return;}
        if("sequence".equals(a.type)){tapGesture(a.x,a.y,55,()->h.postDelayed(()->tapGesture(a.x2,a.y2,55,done),a.gapMs));return;}
        Path p=new Path();p.moveTo(a.x,a.y);long dur=a.duration;
        if("swipe".equals(a.type)||"drag".equals(a.type))p.lineTo(a.x2,a.y2);
        GestureDescription gd=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,dur)).build();dispatch(gd,done);
    }
    private void tapGesture(int x,int y,long dur,Runnable done){Path p=new Path();p.moveTo(x,y);GestureDescription gd=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,dur)).build();dispatch(gd,done);}
    private void dispatch(GestureDescription gd,Runnable done){boolean ok=dispatchGesture(gd,new GestureResultCallback(){@Override public void onCompleted(GestureDescription g){done.run();}@Override public void onCancelled(GestureDescription g){done.run();}},h);if(!ok)h.postDelayed(done,120);}

    private interface CB{void got(String s);}
    private void capture(final CB cb){if(Build.VERSION.SDK_INT<30){cb.got("");return;}final Executor ex=getMainExecutor();takeScreenshot(Display.DEFAULT_DISPLAY,ex,new TakeScreenshotCallback(){@Override public void onSuccess(ScreenshotResult result){HardwareBuffer buffer=null;Bitmap wrapped=null,copy=null;String sig="";try{buffer=result.getHardwareBuffer();wrapped=Bitmap.wrapHardwareBuffer(buffer,result.getColorSpace());if(wrapped!=null)copy=wrapped.copy(Bitmap.Config.ARGB_8888,false);if(copy!=null)sig=signature(copy);}catch(Exception ignored){}finally{if(copy!=null)copy.recycle();if(wrapped!=null)wrapped.recycle();if(buffer!=null)try{buffer.close();}catch(Exception ignored){}}cb.got(sig);}@Override public void onFailure(int errorCode){cb.got("");}});}
    private String signature(Bitmap b){byte[] o=new byte[144];int w=b.getWidth(),hh=b.getHeight();for(int gy=0;gy<12;gy++)for(int gx=0;gx<12;gx++){int x=(int)(w*(.05+.90*(gx+.5)/12)),y=(int)(hh*(.08+.84*(gy+.5)/12));int c=b.getPixel(Math.min(w-1,x),Math.min(hh-1,y));o[gy*12+gx]=(byte)((Color.red(c)*30+Color.green(c)*59+Color.blue(c)*11)/100);}return Base64.encodeToString(o,Base64.NO_WRAP);}
    private int distance(String a,String b){if(a==null||b==null||a.isEmpty()||b.isEmpty())return 0;try{byte[] x=Base64.decode(a,0),y=Base64.decode(b,0);int z=0;for(int i=0;i<Math.min(x.length,y.length);i++)z+=Math.abs((x[i]&255)-(y[i]&255));return z/Math.max(1,Math.min(x.length,y.length));}catch(Exception e){return 0;}}
    private String stateKey(String s){if(s==null||s.isEmpty())return "unknown";try{byte[] a=Base64.decode(s,0);StringBuilder b=new StringBuilder();for(int i=0;i<a.length;i+=6)b.append(Integer.toHexString((a[i]&255)/24));return b.toString();}catch(Exception e){return "unknown";}}
    private void remember(){String n=pkg;try{ApplicationInfo a=getPackageManager().getApplicationInfo(pkg,0);n=getPackageManager().getApplicationLabel(a).toString();}catch(Exception ignored){}ProfileStore.ensureGame(this,pkg,n);}
    private String gameName(){if(!valid())return "افتح لعبة أولًا";try{ApplicationInfo a=getPackageManager().getApplicationInfo(pkg,0);return getPackageManager().getApplicationLabel(a).toString();}catch(Exception e){return pkg;}}
    private boolean valid(){return pkg!=null&&!pkg.isEmpty()&&!pkg.equals(getPackageName())&&!pkg.startsWith("com.android.systemui");}
    private void stop(){discovering=false;playing=false;h.removeCallbacksAndMessages(null);rmPanel();}
    private void rmPanel(){if(panel!=null){rm(panel);panel=null;}}
    private void rm(View v){if(v!=null&&wm!=null)try{wm.removeViewImmediate(v);}catch(Exception ignored){}}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setAllCaps(false);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(104,67,255),Color.rgb(0,184,230)});g.setCornerRadius(dp(15));b.setBackground(g);return b;}
    private TextView txt(String s,int z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);if(bold)t.setTypeface(null,1);return t;}private LinearLayout.LayoutParams lp(int w,int hh){return new LinearLayout.LayoutParams(w,hh);}private LinearLayout.LayoutParams blp(){LinearLayout.LayoutParams p=lp(dp(252),dp(54));p.topMargin=dp(8);return p;}private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    private static final class Action{
        final int x,y,x2,y2;final String type;final long duration,gapMs,settleMs;
        Action(int x,int y,int x2,int y2,String type,long duration,long gap,long settle){this.x=x;this.y=y;this.x2=x2;this.y2=y2;this.type=type;this.duration=duration;this.gapMs=gap;this.settleMs=settle;}
        static Action tap(int x,int y){return new Action(x,y,0,0,"tap",60,0,360);}static Action swipe(int x,int y,int x2,int y2,long d){return new Action(x,y,x2,y2,"swipe",d,0,430);}static Action sequence(int x,int y,int x2,int y2,long gap){return new Action(x,y,x2,y2,"sequence",55,gap,420);}
        JSONObject json(){JSONObject o=new JSONObject();try{o.put("x",x);o.put("y",y);o.put("x2",x2);o.put("y2",y2);o.put("type",type);o.put("duration",duration);o.put("gap",gap);o.put("settle",settleMs);}catch(Exception ignored){}return o;}
        static Action from(JSONObject o){return new Action(o.optInt("x"),o.optInt("y"),o.optInt("x2"),o.optInt("y2"),o.optString("type","tap"),o.optLong("duration",60),o.optLong("gap",80),o.optLong("settle",400));}
    }
}
